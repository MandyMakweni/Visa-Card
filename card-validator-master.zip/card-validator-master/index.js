module.exports = require('./dist/validator');
